# Pixel Castle & Medieval Tileset
87 tiles & sprites, 16x16 pixel art, transparent PNG.
Folders: PNG/native (16x16), PNG/x4 (64x64), spritesheet.png/.json, tileset.png (terrain), sample_scene.png.
Categories: ground, brick, water, nature, props, items, characters, animals.
Engines: set Filter Mode = Point (no filter), Compression = None. Pixels Per Unit = 16.
License: see LICENSE.txt (commercial use OK, no redistribution/resale, credit not required).

# HOLLOW WOODS V3.0 — Vampire Rabbit (Draft)

## Included
- `VampireRabbit_Source_Original.png`: original uploaded source, copied without modification.
- `VampireRabbit_Reference_Sheet_DRAFT.png`: cropped visual concept from the generated reference board. It is for visual discussion only.
- `VampireRabbit_Animation_Metadata_DRAFT.json`: target animation counts and a logical frame order, with all unverified image coordinates/dimensions explicitly left null.

## Not delivered / not production-ready
A valid Production Sprite Sheet was **not** produced. The generated composite preview had a baked checkerboard background (not verified alpha transparency), inconsistent frame-count text, and no trustworthy per-frame cell geometry. Therefore this package does not claim to contain 104 production frames and must not be imported into Phaser as an atlas.

## Required next production pass
1. Create distinct pixel-art drawings for all 104 frames (4 directions × 26 frames).
2. Export each cell with one fixed frame width/height and true RGBA alpha.
3. Validate the grid and every frame visually; reject duplicates or clipped limbs.
4. Measure exact frame rectangles and anchors, then populate the JSON fields currently set to `null`.
5. Test the resulting atlas in Phaser 4 before marking the asset complete.

## Logical animation order
Per direction: IDLE 4, WALK 6, ATTACK 6, HURT 4, DEATH 6. Directions: DOWN, LEFT, RIGHT, UP. Total expected: 104 frames.
